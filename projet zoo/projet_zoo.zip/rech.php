<html>
    <head>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <form method="post" action="rech2.php">
            Rechercher animal : <input type="text" name="rech_text">
            <input type="submit"   value="  Rechercher">
        </form>

    </body>
</html>